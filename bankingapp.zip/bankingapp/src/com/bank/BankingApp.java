package com.bank;

public class BankingApp {
	public static void main(String arg[]) {
		Bank bank = new Bank();
		bank.start();
	}
}
